#ifndef LINKEDLIST_H
#define LINKEDLIST_H

#include "Node.h"

template<class T>
class LinkedList {
public: // DO NOT CHANGE THIS PART.
    LinkedList();
    LinkedList(const LinkedList<T> &obj);

    ~LinkedList();

    int getSize() const;
    bool isEmpty() const;
    bool contains(Node<T> *node) const;

    Node<T> *getDummyHead() const;
    Node<T> *getDummyTail() const;
    Node<T> *getActualHead() const;
    Node<T> *getActualTail() const;
    Node<T> *getNode(const T &data) const;
    Node<T> *getNodeAtIndex(int index) const;

    void insertAtTheBeginning(const T &data);
    void insertAtTheEnd(const T &data);
    void insertBeforeGivenNode(const T &data, Node<T> *node);

    void deleteNode(Node<T> *node);
    void deleteNode(const T &data);
    void deleteAllNodes();

    void swapNodes(Node<T> *node1, Node<T> *node2);

    void traverse() const;

    LinkedList<T> &operator=(const LinkedList<T> &rhs);

private: // YOU MAY ADD YOUR OWN UTILITY MEMBER FUNCTIONS HERE.

private: // DO NOT CHANGE THIS PART.
    Node<T> *dummyHead;
    Node<T> *dummyTail;
};

template<class T>
LinkedList<T>::LinkedList() {
    /* TODO */
}

template<class T>
LinkedList<T>::LinkedList(const LinkedList<T> &obj) {
    /* TODO */
}

template<class T>
LinkedList<T>::~LinkedList() {
    /* TODO */
}

template<class T>
int LinkedList<T>::getSize() const {
    /* TODO */
}

template<class T>
bool LinkedList<T>::isEmpty() const {
    /* TODO */
}

template<class T>
bool LinkedList<T>::contains(Node<T> *node) const {
    /* TODO */
}

template<class T>
Node<T> *LinkedList<T>::getDummyHead() const {
    /* TODO */
}

template<class T>
Node<T> *LinkedList<T>::getDummyTail() const {
    /* TODO */
}

template<class T>
Node<T> *LinkedList<T>::getActualHead() const {
    /* TODO */
}

template<class T>
Node<T> *LinkedList<T>::getActualTail() const {
    /* TODO */
}

template<class T>
Node<T> *LinkedList<T>::getNode(const T &data) const {
    /* TODO */
}

template<class T>
Node<T> *LinkedList<T>::getNodeAtIndex(int index) const {
    /* TODO */
}

template<class T>
void LinkedList<T>::insertAtTheBeginning(const T &data) {
    /* TODO */
}

template<class T>
void LinkedList<T>::insertAtTheEnd(const T &data) {
    /* TODO */
}

template<class T>
void LinkedList<T>::insertBeforeGivenNode(const T &data, Node<T> *node) {
    /* TODO */
}

template<class T>
void LinkedList<T>::deleteNode(Node<T> *node) {
    /* TODO */
}

template<class T>
void LinkedList<T>::deleteNode(const T &data) {
    /* TODO */
}

template<class T>
void LinkedList<T>::deleteAllNodes() {
    /* TODO */
}

template<class T>
void LinkedList<T>::swapNodes(Node<T> *node1, Node<T> *node2) {
    /* TODO */
}

template<class T>
void LinkedList<T>::traverse() const {
    /* ALREADY IMPLEMENTED. DO NOT CHANGE. */

    if (this->isEmpty()) {
        std::cout << "The list is empty." << std::endl;
        return;
    }

    Node<T> *node = this->getActualHead();

    while (node && node->next) {
        std::cout << *node << std::endl;
        node = node->next;
    }
}

template<class T>
LinkedList<T> &LinkedList<T>::operator=(const LinkedList<T> &rhs) {
    /* TODO */
}

#endif //LINKEDLIST_H
