#include "String.h"

String::String() {
    /* ALREADY IMPLEMENTED. DO NOT CHANGE. */
}

String::String(char *str) {
    /* ALREADY IMPLEMENTED. DO NOT CHANGE. */

    // str is a null terminated C string.
    // (e.g. ['h','e','l','l','o','\0'])

    char *temp = str;

    while (*temp != '\0') {
        this->characters.insertAtTheEnd(*temp);
        temp++;
    }
}

int String::getLength() const {
    /* TODO */
}

bool String::isEmpty() const {
    /* TODO */
}

void String::appendCharacter(char character) {
    /* TODO */
}

void String::insertCharacter(char character, int pos) {
    /* TODO */
}

void String::eraseCharacters(int pos, int len) {
    /* TODO */
}

void String::eraseAllCharacters() {
    /* TODO */
}

String String::substring(int pos, int len) {
    /* TODO */
}

LinkedList<String> String::split(char separator) {
    /* TODO */
}

bool String::isPalindrome() const {
    /* TODO */
}

bool String::operator<(const String &rhs) const {
    /* TODO */
}

void String::print(bool verbose) {
    /* ALREADY IMPLEMENTED. DO NOT CHANGE. */

    Node<char> *node = this->characters.getActualHead();
    Node<char> *actualTailNode = this->characters.getActualTail();

    if (verbose) {
        std::cout << "[";
    }

    while (node && node->next) {
        if (verbose) {
            std::cout << "'" << node->data << "'";
            if (node != actualTailNode) {
                std::cout << ",";
            }
        } else {
            std::cout << node->data;
        }

        node = node->next;
    }

    if (verbose) {
        std::cout << "]";
    }

    std::cout << std::endl;
}

std::ostream &operator<<(std::ostream &os, const String &string) {
    /* ALREADY IMPLEMENTED. DO NOT CHANGE. */

    Node<char> *node = string.characters.getActualHead();

    while (node && node->next) {
        os << node->data;
        node = node->next;
    }

    return os;
}
